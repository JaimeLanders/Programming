#include "math.h"

Math::Math()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nMath default constructor " << std::endl;
}

Math::~Math()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nMath destructor " << std::endl;
}

float Math::abs(float value)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath abs " << std::endl;
        std::cout << "value = " << value << std::endl;
    }

    float result = value;

    if (value < 0)
    {
        result = result * -1 ;
    }

    return result;
}

float Math::circArea(float radius)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath circArea " << std::endl;
        std::cout << "radius = " << radius << std::endl;
    }

    float area = pi() * exponent(radius, 2);

    return area;
}

float Math::e()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nMath e " << std::endl;
    float e = 2.71828182845904523536028747135266249775724709369995;

    return e;
}

float Math::exponent (float base, float expo)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nMath exponent " << std::endl;

    float result = base;

    for (int i = 1; i < expo; i++)
    {
        if (debug == true)
            std::cout << "result = " << result << std::endl;

        result = result * base; 
    }

    if (debug == true)
        std::cout << "result = " << result << std::endl;

    return result;
}

/*int Math::factors(int base)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath factors  " << std::endl;
        std::cout << "base = " << base << std::endl;
    }

    int result = 0;

    for (int i = 2; i < base; i++)
    {
        if (debug == true)
            std::cout << "i = " << i << std::endl;

        if (base % i == 0)
    }

    return result;
}
*/
int Math::factorial(int base)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath factorial  " << std::endl;
        std::cout << "base = " << base << std::endl;
    }

    int result = base;

    for (int i = base; i > 1; i--)
    {
        if (debug == true)
            std::cout << "i = " << i << std::endl;

        result = result * (i - 1);    

        if (debug == true)
            std::cout << "result = " << result << std::endl;

    }

    return result;
}

float Math::pi()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nMath pi " << std::endl;
//    float pi = 0;
    float pi = 3.14159265358979323846264338327950288419716939937510;

    return pi;
}

float Math::quadPos(float a, float b, float c)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath quadPos " << std::endl;
        std::cout << "a = " << a << std::endl;
        std::cout << "b = " << b << std::endl;
        std::cout << "c = " << c << std::endl;
    }

    float result = 0;

    result = (((0 - b) + root((exponent(b, 2) - (4 * a * c)),2,3)) / (2 * a));

    if (debug == true)
        std::cout << "result = " << result << std::endl;

    return result;
}

float Math::quadNeg(float a, float b, float c)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMath quadNeg " << std::endl;
        std::cout << "a = " << a << std::endl;
        std::cout << "b = " << b << std::endl;
        std::cout << "c = " << c << std::endl;
    }

    float result = 0;

    result = (((0 - b) - root((exponent(b, 2) - (4 * a * c)),2,3)) / (2 * a));

    if (debug == true)
        std::cout << "result = " << result << std::endl;

    return result;
}

float Math::root (float base, float root, int precision)
{
    bool debug = false;
//    bool debug = true;

    base = abs(base);

    if (debug == true)
    {
        std::cout << "\nMath root " << std::endl;
        std::cout << "base = " << base << std::endl;
        std::cout << "root = " << root << std::endl;
        std::cout << "precision = " << precision << std::endl;
    }

    if (base == 0)
        return 0;
    else if (base == 1)
        return 1;

    float result = 1;

    for (int i = 1; i < base; i++)
    {
        if (debug == true)
            std::cout << "i = " << i << std::endl;
//bp1
        for (int j = 1; j <= root; j++)
        {
            result = i;

            if (debug == true)
                std::cout << "j = " << j << std::endl;

            result = result * i;

            if (debug == true)
                std::cout << "result = " << result << std::endl;

            else if (result == base) // Case 1: perfect square
            {
                return i;
            }
            else if (result > base) // Case 2: fractional result 
            {
                float x_k = i;

                if (debug == true)
                {
                    std::cout << "result > base " << std::endl;
                    std::cout << "x_k = " << x_k << std::endl;
                }

                for (int k = 1; k <= precision; k++)
                {
                    if (debug == true)
                        std::cout << "k = " << k << std::endl;

                    x_k = (0.5*(x_k + (base/x_k))); // Herons formula

                    if (debug == true)
                    {
                        std::cout << "x_k = " << x_k << std::endl;
                        std::cout << "result = " << result << std::endl;
                    }
                }

                result = x_k;

                return result;
            }
        }
    }

    if (debug == true)
        std::cout << "result = " << result << std::endl;

    return result;
}
