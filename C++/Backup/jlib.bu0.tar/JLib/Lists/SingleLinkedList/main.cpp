#include <iostream>
#include "singlelinkedlist.h" 

//using namespace std;

int main ()
{
    SingleLinkedList nList;// = new singlelinkedlist; 
//    char nString [] = "testing";
//    int nNum = 100;
//    int nums [10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    std::cout << "Welcome to SingleLinkedList Driver " << std::endl;

/*    for (int i = 0; i < 10; i++)
    {
        nList.insert(nums[i]);
    }
*/
    nList.insert(100);
    nList.insert(69);
    nList.insert(101);
    nList.insert(77);
    nList.insert(53);

    std::cout << "nList size = " << nList.size() << std::endl;;

    nList.print();

    return 0;
}
