#ifndef _MATH_
#define _MATH_

#include <iostream>

class Math
{
public:
Math();
~Math();

// Constants
float e();                          // Return e constant 
float pi();                         // Return pi constant

// Basic operations
float abs(float);                   // Calculate absolute value
int cieling(float);                 // Calculate cieling 
float divide (float, float);              // Calculate division 
float exponent(float, float);       // Calculate exponent
int factorial(int);                 // Calculate factorial
int fibonacci(int);                 // Calculate fibbonaci sequence
int floor(float);                   // Calculate floor 
//int factors(int);                   // Calculate prime factors, needs data structure 
float gcd (float, float);                 // Calculate greatest common denominator
//float log(float, int, int);         // Calculate logarithm 
//float log2(float, int, int);         // Calculate logarithm 
//float ln(float);                  // Calculate natural logarithm 
int mod(float, float);              // Calculate modulus  
float quadNeg(float, float, float); // (-) Factor using quadratic formula
float quadPos(float, float, float); // (+) Factor using quadratic formula
float root(float, float, int);      // Calculate root

// Geometric 
float circArea(float);              // Calculate area of circle
//float circCirc(int);                // Calculate circumference of circle
float pythag(float, float, float);  // Calculate pythagoreans theorem
//float rectArea(int, int);           // Calculate area of rectangle
//float squareArea(int, int);         // Calculate area of square
//float surfArea                      // Calculate surface area of...
//float triArea(int, int);            // Calculate area of triangle

// Conversions
float degToRad(float);              // Convert degrees to radians
//float kmMi();                       // Convert kilometers to miles
//float miKm(float);                  // Convert miles to kilometers
float radToDeg(float);              // Convert radians to degrees

// Trig Functions
//int arcCos(float);                  // Caluclate arc cosine
//int arcSin(float);                  // Calculate arc sine
//int arcTan(float);                  // Calculate arc tangent
float cos(float);                     // Calculate cosine
float cot(float);                     // Caculate cotangent
float csc(float);                     // Calculate cosecant
float sec(float);                     // Caculcate secent
float sin(float);                     // Calculate sine
float tan(float);                     // Calculate tangent
};

#endif
