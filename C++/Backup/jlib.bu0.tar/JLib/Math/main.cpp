#include <iostream>
#include "math.h"

int main()
{
    Math nMath; 
    
    float a = 1;
    float b = 3;
    float c = 2;
    int precision = 3;
    float result = 0;

    std::cout << "Welcome to math.h driver " << std::endl;
/*
    std::cout << "e = " << nMath.e() << std::endl;
    std::cout << "pi = " << nMath.pi() << std::endl;

    result = nMath.exponent(nMath.e(), b);
    std::cout << "exponent result = " << result << std::endl;

    result = nMath.factorial(result);
    std::cout << "factorial result = " << result << std::endl;
*/
//    result = nMath.abs(-12);
//    std::cout << "abs result = " << result << std::endl;

//    result = nMath.root(-12, 2, precision);
    std::cout << "root result = " << result << std::endl;
/*
    result = nMath.circArea(result);
    std::cout << "circArea result = " << result << std::endl;
*/
    result = nMath.quadPos(a, b, c);
    std::cout << "quadPos result = " << result << std::endl;

    result = nMath.quadNeg(a, b, c);
    std::cout << "quadNeg result = " << result << std::endl;

    return 0;
}
