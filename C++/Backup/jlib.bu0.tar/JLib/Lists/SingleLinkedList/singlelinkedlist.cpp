#include "singlelinkedlist.h"

//using namespace std;

/*ListNode::ListNode()
{
    std::cout << "listnode constructor " << std::endl;
}

Listnode::~Listnode()
{
    std::cout << "listnode destructor " << std::endl;
}
*/
SingleLinkedList::SingleLinkedList()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "singlelinkedlist constructor" << std::endl;

    head = NULL;
//    head->setNext();// = NULL; // Seg faults

    return;

}

SingleLinkedList::~SingleLinkedList()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nsinglelinkedlist destructor" << std::endl;

//    Node *it = head;
    ListNode *it = head;
//    Node *temp = head;
    ListNode *temp = head;

    while (it != NULL)
    {
        temp = (ListNode*)it->next;
        it->next = NULL;
        delete it;
        it = temp;
    }
    
    head = NULL;

    return;
}

void SingleLinkedList::insert(int n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList insert" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    ListNode * nNode = new ListNode; 

    nNode->data = n;

    if (head == NULL) // Case 1: list empty
    {
        if (debug == true)
            std::cout << "Creating new list " << std::endl;

        head = nNode;
    }
    else // Case 2: list not empy
    {
        if (debug == true)
            std::cout << "Adding to list " << std::endl;

        if (n < head->data) // Case 2A : n is new head
        {
            if (debug == true)
                std::cout << "New head " << std::endl;

            nNode->next = head;

            head = nNode;

        }
        else // Case 2B : n is after head
        {
//            Node * it = (ListNode*)head;
            ListNode * it = head;
//            Node * prev  = head;
            ListNode * prev  = head;

            while (it->next != NULL)
            {
                if (debug == true)
                    std::cout << "it != NULL " << std::endl;

                if (n < it->data)
                {
                    if (debug == true)
                        std::cout << "n < it " << std::endl;

                    nNode->next = it;
                    prev->next = nNode;
                    break;
                }
                else
                {
                    if (debug == true)
                        std::cout << "it->next " << std::endl;
                    prev = it;
                    it = (ListNode*)it->next;
                }
            }

            if (it->next == NULL)
            {
                if (debug == true)
                    std::cout << "End of list " << std::endl;

                it->next = nNode; 
                it->next->next = NULL;
            }
       }
    }

    return;
}

void SingleLinkedList::print()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nSingleLinkedList print" << std::endl;
    
//    Node * it = head;
    ListNode * it = head;

    while (it != NULL)
//    while (it->next != NULL)
    {
        std::cout << it->data << std::endl;
        it = (ListNode*)it->next;
    }

    return;
}

int SingleLinkedList::size()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "SingleLinkedList size " << std::endl;

    int size = 0;

    for (ListNode * it = head; it != NULL; it = (ListNode*)it->next)
    {
        size++;
    }

    return size;

}
