#include <iostream>
#include "slist.h" 

//using namespace std;
class testData
{
private:
    int number;
//    char string[];
public:
    testData()
    {
        number = 0;
//        string []= {'\0'};
    }
    ~testData()
    {
        number = 0;
    }

    void setData(int n)
    {
        number = n;
    }
    int getData()
    {
        return number;
    }
//    char * string = "testing";
};
/*
void search(char s[], SingleLinkedList<int> l)
{
    bool debug = false;
//    bool debug = true;

    if (cList.search(s) == true)
        std::cout << s << " found" << std::endl;
    else
        std::cout << s << " not found" << std::endl;

    return;
}
*/
int main ()
{
//    SingleLinkedList<int> nList;// = new singlelinkedlist; 
//    SingleLinkedList<char*> cList;// = new singlelinkedlist; 
    SingleLinkedList<testData> dList;// = new singlelinkedlist; 
    char mString [] = "one";
    char nString [] = "testing";
    char oString [] = "zzz";
//    int nums [10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    testData * nData = new testData;

    std::cout << "Welcome to SingleLinkedList Driver " << std::endl;

/*  // nList Operations
    for (int i = 0; i < 10; i++)
    {
        nList.insert(nums[i]);
    }

    nList.insert(100);
    nList.insert(69);
    nList.insert(101);
    nList.insert(77);
    nList.insert(53);

    std::cout << "nList size = " << nList.size() << std::endl;;

    nList.print();

    // cList operations
    cList.insert(nString);

    std::cout << "cList size = " << cList.size() << std::endl;;

    cList.insert(mString);

    std::cout << "cList size = " << cList.size() << std::endl;;

    cList.insert(oString);

    std::cout << "cList size = " << cList.size() << std::endl;;

    cList.print();

    if (cList.search(nString) == true)
        std::cout << nString << " found" << std::endl;
    else
        std::cout << nString << " not found" << std::endl;

    char lString [] = "two";

    if (cList.search(lString) == true)
        std::cout << lString << " found" << std::endl;
    else
        std::cout << lString << " not found" << std::endl;


    cList.insertHead(nString);
    cList.insertHead(oString);
    cList.insertHead(mString);
    
    std::cout << "cList size = " << cList.size() << std::endl;;
    cList.print();

    cList.insertTail(nString);
    cList.insertTail(oString);
    cList.insertTail(mString);

    std::cout << "cList size = " << cList.size() << std::endl;;
    cList.print();

//    cList.remove(lString);
    cList.remove(mString);
    cList.remove(nString);
    cList.remove(oString);

//    std::cout << "cList size = " << cList.size() << std::endl;;

*/  //dList operations 

    nData->setData(123);
    std::cout << "nData = " << nData->getData() << std::endl;;

//    dList.insert(*nData); // Does not compile
//    dList.insertHead(*nData); // Does not compile
//    dList.print();

    return 0;
}
