#ifndef _SINGLE_LINKED_LIST_
#define _SINGLE_LINKED_LIST_

#include <iostream>
#include "../../Node/node.h"

//using namespace std;

class ListNode : public Node
{
protected:
    // Node * next;
public:
    // node();
    // virtial ~node();
//    char * data;
//    ListNode * next;
    int data;
};

class SingleLinkedList
{
private:
    ListNode * head;
public:
    SingleLinkedList();     // Default constructor
    ~SingleLinkedList();    // Destructor
    void insert(int);       // Iterative insert
    void print();           // Print list
    ListNode* search();     // Print list
    int size();             // Size of list
};

#endif
