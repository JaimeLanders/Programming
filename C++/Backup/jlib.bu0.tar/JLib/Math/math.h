#ifndef _MATH_
#define _MATH_

#include <iostream>

class Math
{
public:
Math();
~Math();

// Constants
float e();                          // Return e constant 
float pi();                         // Return pi constant

// Basic operations
float abs(float);
float exponent(float, float);       // Calculate exponent
int factorial(int);                 // Calculate factorial
int factors(int);                   // Calculate prime factors 
//float log(int, float);              // Calculate logarithm 
//float logN(float);                  // Calculate natural logarithm 
float quadNeg(float, float, float);       // (+) Factor using quadratic formula
float quadPos(float, float, float);       // (+) Factor using quadratic formula
float root(float, float, int);           // Calculate root

// Geometric 
float circArea(float);                // Calculate area of circle
//float circCirc(int);                // Calculate circumference of circle
//float pythag(int, int, int)         // Calculate pythagoreans theorem
//float rectArea(int, int);           // Calculate area of rectangle
//float squareArea(int, int);         // Calculate area of square
//float surfArea                      // Calculate surface area of...
//float triArea(int, int);            // Calculate area of triangle

// Conversions
//float degToRad();                   // Convert degrees to radians
//float kmMi();                       // Convert kilometers to miles
//float miKm(float);                  // Convert miles to kilometers
//int radToDeg();                     // Convert radians to degrees

// Trig Functions
//int arcCos(float);                  // Caluclate arc cosine
//int arcSin(float);                  // Calculate arc sine
//int arcTan(float);                  // Calculate arc tangent
//float cos(int);                     // Calculate cosine
//float cot(int);                     // Caculate cotangent
//float csc(int);                     // Calculate cosecant
//float sec(int);                     // Caculcate secent
//float sin(int);                     // Calculate sine
//float tan(int);                     // Calculate tangent

};

#endif
