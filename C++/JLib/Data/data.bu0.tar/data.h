/*  TODO:
 *
*/
 
#ifndef _DATA_H_
#define _DATA_H_

#include <iostream>

template <class T>
class Data
{
private:
    T data{};
public:
    Data(){};
    ~Data(){};
    friend std::ostream& operator << (std::ostream& os, const Data<T>& param)
    {
        os << param.data;

        return os;
    }
    friend bool operator == (const Data<T>& d1, const Data<T>& d2)
    {
        if (d1.data == d2.data)
            return true;
        else
            return false;
    }
    friend bool operator < (const Data<T>& d1, const Data<T>& d2)
    {
        if (d1.data < d2.data)
            return true;
        else
            return false;
    }
    friend bool operator > (const Data<T>& d1, const Data<T>& d2)
    {
        if (d1.data > d2.data)
            return true;
        else
            return false;
    }
    T getData()
    {
        return data;
    }
    void setData(T n)
    {
        data = n;
    }
};

#endif
