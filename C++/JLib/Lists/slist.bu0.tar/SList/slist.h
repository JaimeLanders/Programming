#ifndef _SINGLE_LINKED_LIST_
#define _SINGLE_LINKED_LIST_

#include <iostream>
#include <string>
//#include "../../Node/node.h"

//using namespace std;

template<class T>
struct ListNode// : public Node
{
    ListNode(){next = NULL;};
    ~ListNode(){};
    ListNode * next;
    T data;
};

template<class T>
class SingleLinkedList
{
private:
    ListNode<T> * head;
    ListNode<T> * tail;
    unsigned int listsize;
public:
    SingleLinkedList();         // Default constructor
    ~SingleLinkedList();        // Destructor
    bool remove(T);             // Remove from list 
    void insert(T);             // In order insert
    void insertHead(T);         // Insert at head
//    void insertPos(T, int);     // Insert at position (needs built) 
    void insertTail(T);         // Insert at tail
    void print();               // Print list
    bool search(T);             // Search list
    int size();                 // Return size of list
};

//#include "singlelinkedlist.cpp" // Fix for templates

template<class T>
SingleLinkedList<T>::SingleLinkedList()
{
    bool debug = false;
//   bool debug = true;

    if (debug == true)
        std::cout << "singlelinkedlist constructor" << std::endl;

    head = nullptr;
    tail = nullptr;
    listsize = 0;

    return;

}

template<class T>
SingleLinkedList<T>::~SingleLinkedList()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nsinglelinkedlist destructor" << std::endl;

    ListNode<T> *it = head;
    ListNode<T> *temp = head;

    while (it != NULL)
    {
        temp = (ListNode<T>*)it->next;
        it->next = NULL;
        delete it;
        it = temp;
    }
    
    head = NULL;

    return;
}

template<class T>
void SingleLinkedList<T>::insert(T n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList insert" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    ListNode<T> * nNode = new ListNode<T>; 

    nNode->data = n;

    if (head == NULL) // Case 1: list empty
    {
        if (debug == true)
            std::cout << "Creating new list " << std::endl;

        head = nNode;
        tail = nNode;

        listsize++;
    }
    else // Case 2: list not empy
    {
        if (debug == true)
            std::cout << "Adding to list " << std::endl;

        if (n < head->data) // Case 2A : n is new head
        {
            if (debug == true)
                std::cout << "New head " << std::endl;

            nNode->next = head;

            head = nNode;

            listsize++;

        }
        else // Case 2B : n is after head
        {
            ListNode<T> * it = head;
            ListNode<T> * prev  = head;

            while (it->next != NULL)
            {
                if (debug == true)
                    std::cout << "it != NULL " << std::endl;

                if (n < it->data)
                {
                    if (debug == true)
                        std::cout << "n < it " << std::endl;

                    nNode->next = it;
                    prev->next = nNode;
                    listsize++;
                    break;
                }
                else
                {
                    if (debug == true)
                        std::cout << "it->next " << std::endl;
                    prev = it;
                    it = (ListNode<T>*)it->next;
                }
            }

            if (it->next == NULL)
            {
                if (debug == true)
                    std::cout << "End of list " << std::endl;

                it->next = nNode; 
                it->next->next = NULL;
                tail = nNode;
                listsize++;
            }
       }
    }

    return;
}

template<class T>
void SingleLinkedList<T>::insertHead(T n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList insertHead" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    ListNode<T> * nNode = new ListNode<T>; 

    nNode->data = n;

    if (head == NULL) // Case 1: list empty
    {
        if (debug == true)
            std::cout << "Creating new list " << std::endl;

        head = nNode;
        tail = nNode;

        listsize++;
    }
    else // Case 2: list not empy
    {
        if (debug == true)
            std::cout << "Adding to list " << std::endl;

        if (n < head->data) // Case 2A : n is new head
        {
            if (debug == true)
                std::cout << "New head " << std::endl;

            nNode->next = head;

            head = nNode;

            listsize++;

        }
    }

    return;
}

template<class T>
void SingleLinkedList<T>::insertTail(T n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList insertTail" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    ListNode<T> * nNode = new ListNode<T>; 

    nNode->data = n;

    if (head == NULL) // Case 1: list empty
    {
        if (debug == true)
            std::cout << "Creating new list " << std::endl;

        head = nNode;
        tail = nNode;

        listsize++;
    }
    else // Case 2: list not empy
    {
        if (debug == true)
            std::cout << "Adding to list " << std::endl;

        if (n < head->data) // Case 2A : n is new tail 
        {
            if (debug == true)
                std::cout << "New tail " << std::endl;


            tail->next = nNode;
            tail = nNode;

            listsize++;

        }
    }

    return;
}

template<class T>
void SingleLinkedList<T>::print()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "\nSingleLinkedList print" << std::endl;
    
    ListNode<T> * it = head;

    while (it != NULL)
    {
        std::cout << it->data << std::endl;
        it = (ListNode<T>*)it->next;
    }

    return;
}

template<class T>
bool SingleLinkedList<T>::remove(T n)
{
//    bool debug = false;
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList remove" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    bool found = false;

    for (ListNode<T> * it = head; it != NULL; it = (ListNode<T>*)it->next)
    {
       if (it->data == n) 
       {
           ListNode<T> * temp;

            if(it == head && it == tail) // Head and tail
            {
                if (debug == true)
                    std::cout << n << " is head and tail " << std::endl;

                temp = head;
                head = NULL;
                tail = NULL;
                it = NULL;
                delete temp;
                listsize--;
                break; // Fix for segfault on empty list after
            }
            else if(it == head) // Head
            {
                if (debug == true)
                    std::cout << n << " is head " << std::endl;

                temp = head;
                head = head->next;
                it = head;
                delete temp;
                listsize--;
            }
            else if(it == tail) // Tail
            {
                if (debug == true)
                    std::cout << n << " is tail " << std::endl;

                temp = tail;

                for (ListNode<T> * it2 = head; it2->next == tail; it2 = (ListNode<T>*)it2->next)
                {
                    tail = it2;
                    it2 = NULL;
                }

                it = tail;
                delete temp; // Valgrind errors
                listsize--;
            }
            else // Not head or tail
            {
                if (debug == true)
                    std::cout << n << " is neither nor head or tail " << std::endl;

                temp = it;

                ListNode<T> * prev;

                for (ListNode<T> * it2 = head; it2->next == it; it2 = (ListNode<T>*)it2->next)
                {
                    prev = it2;
                }

                prev->next = it->next;

                it = prev->next;
                delete temp;
                listsize--;
           }
           found = true;
       }
    }

    if (found == true) 
    {
        if (debug == true)
            std::cout << n << " found and deleted " << std::endl;

        return true;
    }
    else
    {
        if (debug == true)
            std::cout << n << " not found " << std::endl;

        return false;
    }
}

template<class T>
bool SingleLinkedList<T>::search(T n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nSingleLinkedList search" << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    bool found = false;

    for (ListNode<T> * it = head; it != NULL; it = (ListNode<T>*)it->next)
    {
       if (it->data == n) 
           found = true;
    }

    if (found == true) 
    {
        if (debug == true)
            std::cout << n << " found " << std::endl;

        return true;
    }
    else
    {
        if (debug == true)
            std::cout << n << " not found " << std::endl;

        return false;
    }
}

template<class T>
int SingleLinkedList<T>::size()
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
        std::cout << "SingleLinkedList size " << std::endl;

    return listsize;
}


#endif
